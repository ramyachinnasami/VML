const jwt = require('jsonwebtoken');
const util = require('util');
const _ = require('lodash');
const jwt_decode = require('jwt-decode');
const conf = require('../../config');
const response = require('../../config/response');
const request = require('request');

const authService = 'http://localhost:3000';


module.exports = {
  login,
  forgotPassword,
  getAllUserByInput,
  userChangePassword
};

/**
 * login API and Authenticate user credentials, generate token
 * @param req a handle to the request object
 * @param res a handle to the response object
 * @returns Returning user's basic informations along with token id
 */
function login(req, res) {
  const { emailId, password } = req.swagger.params.body.value;
  request.post({
      headers: {'content-type': 'application/json'},
      url: `${authService}/login`,
      body: `{"emailId":"sooraj@gmail.com","password":"1234"}`
  }, (err, loginResponse, body) => {
        if(err){
          if (util.isError(err)) res.error('NotFoundError', err); // return 404
          else res.error('InternalServerError', err); // else 500
        }
       res.send(response.success('Login Successfully', body));
  });
}

/**
 * @name: forgotPassword
 * @description :
 * Process to forgot the password and generate digest
 *
 * @return {object} body - user details
 */
function forgotPassword(req, res) {
  const body = req.swagger.params.body.value;
  request.post({
      headers: {'content-type': 'application/json'},
      url: `${authService}/forgotpassword`,
      body: `{"email":"sooraj@gmail.com"}`
  }, (err, forgotPasswordResponse, body) => {
       if(err){
          if (util.isError(err)) res.error('NotFoundError', err); // return 404
          else res.error('InternalServerError', err); // else 500
       }
       res.send(response.success('Password sent to your Mail id Successfully.'));
  });
}


/**
 * @name: getAllUserByInput
 * @description : Get the All the user by input
 *
 * @return {object} user details
 */
function getAllUserByInput(req, res) {
  const username = req.query.user_name;
  request.post({
      headers: {'content-type': 'application/json'},
      url: `${authService}/user_filter?user_name=username `,
  }, (err, userResponse, body) => {
       if(err){
          if (util.isError(err)) res.error('NotFoundError', err); // return 404
          else res.error('InternalServerError', err); // else 500
       }
       res.send(response.success(userResponse));
  });
}

/**
 * @name: userChangePassword
 * @description : removing unwanted menu based on roll
 */
function userChangePassword(req, res) {
  const changePwd = req.swagger.params.body.value;

  const token = req.headers.authorization;
  token.replace('Bearer ', '');
  const decoded = jwt_decode(token);

  request.post({
      headers: {'content-type': 'application/json'},
      url: `${authService}/changepassword`,
      body: `{"newPassword":"8jhdsd"}`
  }, (err, changepasswordResponse, body) => {
        if(err){
          if (util.isError(err)) res.error('NotFoundError', err); // return 404
          else res.error('InternalServerError', err); // else 500
        }
        const newpass = changePwd.newPassword;
        const user_id = decoded.userId;
       res.send(response.success('The password has been changed successfully', []));
  });
}
