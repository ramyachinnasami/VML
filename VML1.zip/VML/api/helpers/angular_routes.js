

exports.routesData = function () {
  return [
    {
      path: '',
      redirectTo: '/dashboard',
      pathMatch: 'full'
    }
  ];
};
