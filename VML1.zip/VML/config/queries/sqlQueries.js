module.exports = {
  login: {
    query: 'SELECT "emailId", "name", "userId", "role", "userTeam" FROM master_catalog.user WHERE "status" > 0 AND LOWER("emailId") = LOWER($1) and "password" = $2',
    user: 'select * from master_catalog."user" where "status" = 1 AND "userId" = $1',
    updatePwd: 'update master_catalog."user" set "password" = $1 where "userId" = $2'
  },
  common: {
    getrolebyid: 'SELECT "role" FROM master_catalog."user" where "userId"=$1'
  }
};
