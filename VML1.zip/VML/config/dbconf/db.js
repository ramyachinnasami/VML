const pgp = require('pg-promise')();


const util = require('util');

// set default pooling
pgp.pg.defaults.poolSize = 100;

/**
 * Initialize Environment values
 */
global.db = {};

/**
 * Initialize master database connection
 */
function initDBConnection() {
  return new Promise((resolve, reject) => {
    const db_config = (!util.isNullOrUndefined(env_configuration)) ? env_configuration : {};

    db = pgp(db_config);
    resolve(db);
  });
}

module.exports.initDBConnection = initDBConnection;
