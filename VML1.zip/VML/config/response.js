

/**
 * Return success reponse with formatted object
 * @param msg displaying success message
 * @param data passing custom data to front end
 * @returns formatted output object
 */
exports.success = function (msg, data) {
  return {
    code: '01',
    message: msg,
    response: data
  };
};
exports.error = function (msg, data) {
  return {
    code: '02',
    message: msg
  };
};
