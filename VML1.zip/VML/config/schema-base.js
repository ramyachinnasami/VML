module.exports = {
  env: {
    doc: 'The applicaton environment.',
    format: ['development', 'staging', 'production', 'test'],
    default: 'development',
    env: 'NODE_ENV'
  },
  ip: {
    doc: 'The IP address to bind.',
    format: 'ipaddress',
    default: '127.0.0.1',
    env: 'IP_ADDRESS'
  },
  port: {
    doc: 'The port to bind.',
    format: 'port',
    default: 3002,
    env: 'PORT'
  },
  appRoot: {
    doc: 'Required by Swagger.',
    format: String,
    default: process.cwd(),
    env: 'PWD'
  },
  logging: {
    format: {
      doc: 'How to format the logs. Uses %{level} syntax for variables',
      format: String,
      default: null
    },
    transport: {
      doc: 'Where to write logs',
      format: ['stdout', 'file'],
      default: 'stdout'
    },
    level: {
      doc: 'Lowest level to log',
      format: ['fatal', 'error', 'warn', 'info', 'debug', 'trace', 'silent'],
      default: 'warn'
    },
    dir: {
      doc: 'Required for file-based logging',
      format: String,
      default: 'logs'
    },
    extreme: {
      doc: 'Enables extreme mode, yields an additional 60% performance',
      format: Boolean,
      default: true
    },
    name: {
      doc: 'Name of the app to be logged',
      format: String,
      default: ''
    }
  },
  configManager: {
    host: {
      doc: 'Database host name/IP',
      format: '*',
      default: '192.168.4.141'
    },
    port: {
      doc: 'The port to bind.',
      format: 'port',
      default: 5432
    },
    database: {
      doc: 'Database name',
      format: String,
      default: 'screener-web-portal'
    },
    user: {
      doc: 'Name of the user',
      format: String,
      default: 'postgres'
    },
    password: {
      doc: 'password',
      format: String,
      default: 'root'
    }
  },
  jwt: {
    secret: {
      doc: 'Secret key of the app',
      format: String,
      default: '&@$!changeme!$@&'
    }
  },
  nodemailerAuth: {
    password: {
      doc: 'Password to create transport',
      format: String,
      default: 'aimtowin1*'
    }
  },
  mailerConfig: {
    host: '192.168.4.101',
    port: 2525,
    secure: false, // true for 465, false for other ports
    auth: {
      user: 'ramya.chinnasamy@dsrc.co.in', //  user
      pass: '********' //  password
    }
  },
  url: {
    login_url: 'http://localhost:4200/user/login',
    email_direct_url: 'http://localhost:4200/emaildirectlink',
    encrytptionKey: '@#$234'
  },
  status: {
    emailSend: 1
  }
};
