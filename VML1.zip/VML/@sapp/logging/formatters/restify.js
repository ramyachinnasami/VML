

const util = require('util');

const LABELS = require('pino').levels.labels;

module.exports = (template, messageType) => (log) => {
  const req = log.req || {};

  // template returning the constructed logging format
  return template({
    time: log.time,
    name: log.name,
    hostname: log.hostname,
    level: String(LABELS[log.level]).toUpperCase(),
    role: log.role,
    type: messageType(log.role, log.direction),

    id: log.reqId,
    correlation: req.headers && req.headers['x-correlation-id'],
    parent: null,

    method: req.method,
    url: req.url,
    statusCode: log.res && log.res.statusCode,

    msg: util.isString(log.msg) ? log.msg : JSON.stringify(log.msg)
  });
};
